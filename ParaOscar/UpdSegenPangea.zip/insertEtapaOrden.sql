INSERT INTO etapa_orden (
mensaje_xnear, 
ident_etapa,
fecha_etapa
)VALUES(
:#mensajeXnear,
'RQ',
CURRENT
)

